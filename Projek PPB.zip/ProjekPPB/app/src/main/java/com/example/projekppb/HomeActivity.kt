package com.example.projekppb

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val txtBahagia = findViewById<TextView>(R.id.txtBahagia)
        val txtSedih = findViewById<TextView>(R.id.txtSedih)
        val barChart = findViewById<BarChart>(R.id.barChart)

        val mood = intent.getStringExtra("mood") ?: ""

        val sharedPref = getSharedPreferences("MoodData", Context.MODE_PRIVATE)

        var bahagia = sharedPref.getInt("bahagia", 0)
        var sedih = sharedPref.getInt("sedih", 0)

        if (mood == "Bahagia") {
            bahagia++
        }

        if (mood == "Sedih") {
            sedih++
        }

        val editor = sharedPref.edit()
        editor.putInt("bahagia", bahagia)
        editor.putInt("sedih", sedih)
        editor.apply()

        txtBahagia.text = bahagia.toString()
        txtSedih.text = sedih.toString()

        val entries = ArrayList<BarEntry>()

        entries.add(BarEntry(0f, bahagia.toFloat()))
        entries.add(BarEntry(1f, sedih.toFloat()))

        val dataSet = BarDataSet(entries, "Mood")

        dataSet.setColors(
            Color.parseColor("#A8E6DE"),
            Color.parseColor("#5A6FF0")
        )

        dataSet.valueTextSize = 14f

        val data = BarData(dataSet)

        barChart.data = data

        val labels = ArrayList<String>()
        labels.add("Bahagia")
        labels.add("Sedih")

        val xAxis = barChart.xAxis
        xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        xAxis.granularity = 1f
        xAxis.setDrawGridLines(false)

        barChart.axisRight.isEnabled = false
        barChart.description.isEnabled = false
        barChart.animateY(1500)

        barChart.invalidate()
    }

}
