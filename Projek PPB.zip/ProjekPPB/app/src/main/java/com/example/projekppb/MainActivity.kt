package com.example.projekppb

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnTenang = findViewById<Button>(R.id.btnTenang)
        val btnKhawatir = findViewById<Button>(R.id.btnKhawatir)
        val btnBahagia = findViewById<Button>(R.id.btnBahagia)
        val btnMalu = findViewById<Button>(R.id.btnMalu)
        val btnSakit = findViewById<Button>(R.id.btnSakit)
        val btnBingung = findViewById<Button>(R.id.btnBingung)
        val btnBosan = findViewById<Button>(R.id.btnBosan)
        val btnSeru = findViewById<Button>(R.id.btnSeru)
        val btnSantai = findViewById<Button>(R.id.btnSantai)
        val btnMarah = findViewById<Button>(R.id.btnMarah)
        val btnSedih = findViewById<Button>(R.id.btnSedih)

        btnTenang.setOnClickListener {
            pindahHalaman("😌", "Tenang")
        }

        btnKhawatir.setOnClickListener {
            pindahHalaman("😟", "Khawatir")
        }

        btnBahagia.setOnClickListener {
            pindahHalaman("😊", "Bahagia")
        }

        btnMalu.setOnClickListener {
            pindahHalaman("😳", "Malu")
        }

        btnSakit.setOnClickListener {
            pindahHalaman("🤒", "Sakit")
        }

        btnBingung.setOnClickListener {
            pindahHalaman("😕", "Bingung")
        }

        btnBosan.setOnClickListener {
            pindahHalaman("😑", "Bosan")
        }

        btnSeru.setOnClickListener {
            pindahHalaman("🤩", "Seru")
        }

        btnSantai.setOnClickListener {
            pindahHalaman("😎", "Santai")
        }

        btnMarah.setOnClickListener {
            pindahHalaman("😠", "Marah")
        }

        btnSedih.setOnClickListener {
            pindahHalaman("😢", "Sedih")
        }
    }

    private fun pindahHalaman(emoji: String, mood: String) {

        val intent = Intent(this, HomeActivity::class.java)

        intent.putExtra("emoji", emoji)
        intent.putExtra("mood", mood)

        startActivity(intent)
    }
}